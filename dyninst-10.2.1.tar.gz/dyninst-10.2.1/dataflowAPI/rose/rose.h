#if !defined(ROSE_H)
#define ROSE_H

#define ROSE_ASSERT assert

#endif
