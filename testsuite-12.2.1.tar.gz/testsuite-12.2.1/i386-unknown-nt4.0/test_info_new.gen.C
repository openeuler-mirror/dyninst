/* This file automatically generated from test specifications.  See
 * specification/spec.pl and specification/makemake.py
 */

#include "test_info_new.h"



static unsigned int test_count = 0;
static unsigned int group_count = 0;
static std::vector<RunGroup *> *tests = NULL;

static void fini_group(RunGroup *rg) {
  rg->index = group_count++;
  tests->push_back(rg);
  test_count = 0;
}

static void add_test(RunGroup *rg, const char *ts) {
  rg->tests.push_back(new TestInfo(test_count++, ".dll", ts));
}

// Now we insert the test lists into the run groups
void initialize_mutatees(std::vector<RunGroup *> &t) {
        tests = &t;
	RunGroup *rg;
  rg = new RunGroup("test_thread_6.dyn_VC_32_none_low.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC_32_none_low.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC_32_none_high.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC_32_none_high.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC_32_none_max.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC_32_none_max.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC_32_none_none.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC_32_none_none.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC++_32_none_low.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC++_32_none_low.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC++_32_none_high.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC++_32_none_high.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC++_32_none_max.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC++_32_none_max.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC++_32_none_none.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_6.dyn_VC++_32_none_none.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test_thread_6, mutator: test_thread_6, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_6, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC_32_none_low.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC_32_none_low.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC_32_none_high.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC_32_none_high.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC_32_none_max.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC_32_none_max.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC_32_none_none.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC_32_none_none.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC++_32_none_low.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC++_32_none_low.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC++_32_none_high.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC++_32_none_high.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC++_32_none_max.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC++_32_none_max.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC++_32_none_none.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_7.dyn_VC++_32_none_none.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test_thread_7, mutator: test_thread_7, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_7, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC_32_none_low.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC_32_none_low.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC_32_none_high.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC_32_none_high.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC_32_none_max.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC_32_none_max.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC_32_none_none.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC_32_none_none.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC++_32_none_low.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC++_32_none_low.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC++_32_none_high.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC++_32_none_high.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC++_32_none_max.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC++_32_none_max.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC++_32_none_none.exe", 
		DELAYEDATTACH, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_thread_8.dyn_VC++_32_none_none.exe", 
		DELAYEDATTACH, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test_thread_8, mutator: test_thread_8, grouped: false, pic: none, start_state: delayedattach, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_thread_8, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_launch.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_launch, mutator: pc_launch, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_launch, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread_cont.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread_cont, mutator: pc_thread_cont, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread_cont, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_breakpoint.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_breakpoint, mutator: pc_breakpoint, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_breakpoint, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_library.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_library, mutator: pc_library, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_library, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_addlibrary.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_addlibrary, mutator: pc_addlibrary, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_addlibrary, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_singlestep.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_singlestep, mutator: pc_singlestep, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_singlestep, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_thread.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_thread, mutator: pc_thread, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_thread, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_groups.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_groups, mutator: pc_groups, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_groups, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_stat.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_stat, mutator: pc_stat, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_stat, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_irpc.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_irpc, mutator: pc_irpc, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_irpc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_detach, mutator: pc_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_temp_detach.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_temp_detach, mutator: pc_temp_detach, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_temp_detach, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate, mutator: pc_terminate, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_terminate_stopped.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_terminate_stopped, mutator: pc_terminate_stopped, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_terminate_stopped, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, MultiThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, MultiProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC++_32_none_none.exe", 
		SELFATTACH, CREATE, SingleThreaded, SingleProcess, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: no_launch, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, MultiThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: MultiThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, MultiProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: MultiProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("pc_mem_perm.dyn_VC++_32_none_none.exe", 
		SELFATTACH, USEATTACH, SingleThreaded, SingleProcess, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"proccontrol", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: pc_mem_perm, mutator: pc_mem_perm, grouped: false, pic: none, start_state: selfattach, format: dynamicMutatee, process_mode: SingleProcess, abi: 32, thread_mode: SingleThreaded, mutateeruntime: pre, platmode: NONE, mutatee: pc_mem_perm, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"instruction", "", "none", "32", "NONE");
  add_test(rg, "{test: fucompp, mutator: fucompp, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"instruction", "", "none", "32", "NONE");
  add_test(rg, "{test: mov_size_details, mutator: mov_size_details, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "", "none", "32", "NONE");
  add_test(rg, "{test: test2_1, mutator: test2_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "", "none", "32", "NONE");
  add_test(rg, "{test: test2_2, mutator: test2_2, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("", 
		SELFSTART, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "", "none", "32", "NONE");
  add_test(rg, "{test: test2_3, mutator: test2_3, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("", 
		SELFSTART, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "", "none", "32", "NONE");
  add_test(rg, "{test: test2_4, mutator: test2_4, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"instruction", "", "none", "32", "NONE");
  add_test(rg, "{test: test_instruction_read_write, mutator: test_instruction_read_write, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"instruction", "", "none", "32", "NONE");
  add_test(rg, "{test: test_instruction_farcall, mutator: test_instruction_farcall, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"instruction", "", "none", "32", "NONE");
  add_test(rg, "{test: test_instruction_bind_eval, mutator: test_instruction_bind_eval, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"instruction", "", "none", "32", "NONE");
  add_test(rg, "{test: power_decode, mutator: power_decode, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"instruction", "", "none", "32", "NONE");
  add_test(rg, "{test: aarch64_decode, mutator: aarch64_decode, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"instruction", "", "none", "32", "NONE");
  add_test(rg, "{test: aarch64_cft, mutator: aarch64_cft, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"instruction", "", "none", "32", "NONE");
  add_test(rg, "{test: aarch64_decode_ldst, mutator: aarch64_decode_ldst, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"instruction", "", "none", "32", "NONE");
  add_test(rg, "{test: aarch64_simd, mutator: aarch64_simd, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"instruction", "", "none", "32", "NONE");
  add_test(rg, "{test: power_cft, mutator: power_cft, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: none, mutatorstart: local, optimization: none, mutateestart: local, compiler: , run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC++_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC++_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC++_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC++_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC++_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC++_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC++_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("dyninst_group_test.dyn_VC++_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: snip_change_shlib_var, mutator: snip_change_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: snip_ref_shlib_var, mutator: snip_ref_shlib_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_1, mutator: test1_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_10, mutator: test1_10, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_11, mutator: test1_11, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_13, mutator: test1_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_15, mutator: test1_15, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_16, mutator: test1_16, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_17, mutator: test1_17, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_18, mutator: test1_18, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_2, mutator: test1_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_20, mutator: test1_20, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_21, mutator: test1_21, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_22, mutator: test1_22, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_23, mutator: test1_23, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_24, mutator: test1_24, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_25, mutator: test1_25, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_26, mutator: test1_26, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_27, mutator: test1_27, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_28, mutator: test1_28, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_3, mutator: test1_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_30, mutator: test1_30, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_31, mutator: test1_31, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_32, mutator: test1_32, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_33, mutator: test1_33, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_34, mutator: test1_34, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_36, mutator: test1_36, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_37, mutator: test1_37, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_38, mutator: test1_38, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_4, mutator: test1_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_5, mutator: test1_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_6, mutator: test1_6, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_7, mutator: test1_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_8, mutator: test1_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test1_9, mutator: test1_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_12, mutator: test2_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_13, mutator: test2_13, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_5, mutator: test2_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test2_7, mutator: test2_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test_write_param, mutator: test_write_param, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("dyninst_cxx_group_test.dyn_VC++_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test5_1, mutator: test5_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_2, mutator: test5_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_3, mutator: test5_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_4, mutator: test5_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_5, mutator: test5_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_7, mutator: test5_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_8, mutator: test5_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_9, mutator: test5_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("dyninst_cxx_group_test.dyn_VC++_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test5_1, mutator: test5_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_2, mutator: test5_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_3, mutator: test5_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_4, mutator: test5_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_5, mutator: test5_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_7, mutator: test5_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_8, mutator: test5_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_9, mutator: test5_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("dyninst_cxx_group_test.dyn_VC++_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test5_1, mutator: test5_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_2, mutator: test5_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_3, mutator: test5_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_4, mutator: test5_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_5, mutator: test5_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_7, mutator: test5_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_8, mutator: test5_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_9, mutator: test5_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("dyninst_cxx_group_test.dyn_VC++_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test5_1, mutator: test5_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_2, mutator: test5_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_3, mutator: test5_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_4, mutator: test5_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_5, mutator: test5_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_7, mutator: test5_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_8, mutator: test5_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_9, mutator: test5_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("dyninst_cxx_group_test.dyn_VC++_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test5_1, mutator: test5_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_2, mutator: test5_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_3, mutator: test5_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_4, mutator: test5_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_5, mutator: test5_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_7, mutator: test5_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_8, mutator: test5_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_9, mutator: test5_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("dyninst_cxx_group_test.dyn_VC++_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test5_1, mutator: test5_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_2, mutator: test5_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_3, mutator: test5_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_4, mutator: test5_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_5, mutator: test5_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_7, mutator: test5_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_8, mutator: test5_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_9, mutator: test5_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("dyninst_cxx_group_test.dyn_VC++_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test5_1, mutator: test5_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_2, mutator: test5_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_3, mutator: test5_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_4, mutator: test5_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_5, mutator: test5_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_7, mutator: test5_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_8, mutator: test5_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  add_test(rg, "{test: test5_9, mutator: test5_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("dyninst_cxx_group_test.dyn_VC++_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test5_1, mutator: test5_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_2, mutator: test5_2, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_3, mutator: test5_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_4, mutator: test5_4, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_5, mutator: test5_5, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_7, mutator: test5_7, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_8, mutator: test5_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  add_test(rg, "{test: test5_9, mutator: test5_9, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: dyninst_cxx_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("symtab_group_test.dyn_VC_32_none_low.exe", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"symtab", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test_line_info, mutator: test_line_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_local_var_locations, mutator: test_local_var_locations, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_local_var_lookup, mutator: test_local_var_lookup, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_lookup_func, mutator: test_lookup_func, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_lookup_var, mutator: test_lookup_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_module, mutator: test_module, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_type_info, mutator: test_type_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("symtab_group_test.dyn_VC_32_none_high.exe", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"symtab", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test_line_info, mutator: test_line_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_local_var_locations, mutator: test_local_var_locations, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_local_var_lookup, mutator: test_local_var_lookup, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_lookup_func, mutator: test_lookup_func, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_lookup_var, mutator: test_lookup_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_module, mutator: test_module, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_type_info, mutator: test_type_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("symtab_group_test.dyn_VC_32_none_max.exe", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"symtab", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test_line_info, mutator: test_line_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_local_var_locations, mutator: test_local_var_locations, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_local_var_lookup, mutator: test_local_var_lookup, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_lookup_func, mutator: test_lookup_func, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_lookup_var, mutator: test_lookup_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_module, mutator: test_module, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_type_info, mutator: test_type_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("symtab_group_test.dyn_VC_32_none_none.exe", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"symtab", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test_line_info, mutator: test_line_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_local_var_locations, mutator: test_local_var_locations, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_local_var_lookup, mutator: test_local_var_lookup, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_lookup_func, mutator: test_lookup_func, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_lookup_var, mutator: test_lookup_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_module, mutator: test_module, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: disk}");
  add_test(rg, "{test: test_type_info, mutator: test_type_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("symtab_group_test.dyn_VC++_32_none_low.exe", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"symtab", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test_line_info, mutator: test_line_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_local_var_locations, mutator: test_local_var_locations, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_local_var_lookup, mutator: test_local_var_lookup, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_lookup_func, mutator: test_lookup_func, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_lookup_var, mutator: test_lookup_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_module, mutator: test_module, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_type_info, mutator: test_type_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("symtab_group_test.dyn_VC++_32_none_high.exe", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"symtab", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test_line_info, mutator: test_line_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_local_var_locations, mutator: test_local_var_locations, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_local_var_lookup, mutator: test_local_var_lookup, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_lookup_func, mutator: test_lookup_func, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_lookup_var, mutator: test_lookup_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_module, mutator: test_module, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_type_info, mutator: test_type_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("symtab_group_test.dyn_VC++_32_none_max.exe", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"symtab", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test_line_info, mutator: test_line_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_local_var_locations, mutator: test_local_var_locations, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_local_var_lookup, mutator: test_local_var_lookup, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_lookup_func, mutator: test_lookup_func, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_lookup_var, mutator: test_lookup_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_module, mutator: test_module, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_type_info, mutator: test_type_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("symtab_group_test.dyn_VC++_32_none_none.exe", 
		STOPPED, DISK, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"symtab", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test_line_info, mutator: test_line_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_local_var_locations, mutator: test_local_var_locations, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_local_var_lookup, mutator: test_local_var_lookup, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_lookup_func, mutator: test_lookup_func, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_lookup_var, mutator: test_lookup_var, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_module, mutator: test_module, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: disk}");
  add_test(rg, "{test: test_type_info, mutator: test_type_info, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: symtab_group_test, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: disk}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC++_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC++_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC++_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC++_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC++_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC++_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC++_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_12.dyn_VC++_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test1_12, mutator: test1_12, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_12, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC++_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC++_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC++_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC++_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC++_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC++_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC++_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_14.dyn_VC++_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test1_14, mutator: test1_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_14, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC++_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC++_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC++_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC++_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC++_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC++_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC++_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_19.dyn_VC++_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test1_19, mutator: test1_19, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_19, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC++_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC++_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC++_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC++_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC++_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC++_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC++_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_reloc.dyn_VC++_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test_reloc, mutator: test_reloc, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_reloc, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC++_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC++_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC++_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC++_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC++_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC++_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC++_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_snip_remove.dyn_VC++_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test_snip_remove, mutator: test_snip_remove, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test_snip_remove, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC++_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC++_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC++_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC++_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC++_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC++_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC++_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test1_29.dyn_VC++_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, false, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test1_29, mutator: test1_29, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test1_29, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC++_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC++_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC++_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC++_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC++_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC++_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC++_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_8.dyn_VC++_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test2_8, mutator: test2_8, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_8, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC++_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC++_32_none_low.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC++_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC++_32_none_high.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC++_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC++_32_none_max.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC++_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test2_14.dyn_VC++_32_none_none.exe", 
		STOPPED, USEATTACH, TNone, PNone, 
		local, local, pre, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test2_14, mutator: test2_14, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: pre, platmode: NONE, mutatee: test2_14, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: useAttach}");
  fini_group(rg);
  rg = new RunGroup("test3_1.dyn_VC_32_none_low.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test3_1, mutator: test3_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_1, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_1.dyn_VC_32_none_high.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test3_1, mutator: test3_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_1, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_1.dyn_VC_32_none_max.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test3_1, mutator: test3_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_1, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_1.dyn_VC_32_none_none.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test3_1, mutator: test3_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_1, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_1.dyn_VC++_32_none_low.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test3_1, mutator: test3_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_1, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_1.dyn_VC++_32_none_high.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test3_1, mutator: test3_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_1, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_1.dyn_VC++_32_none_max.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test3_1, mutator: test3_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_1, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_1.dyn_VC++_32_none_none.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test3_1, mutator: test3_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_1, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_2.dyn_VC_32_none_low.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test3_2, mutator: test3_2, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_2, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_2.dyn_VC_32_none_high.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test3_2, mutator: test3_2, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_2, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_2.dyn_VC_32_none_max.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test3_2, mutator: test3_2, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_2, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_2.dyn_VC_32_none_none.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test3_2, mutator: test3_2, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_2, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_2.dyn_VC++_32_none_low.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test3_2, mutator: test3_2, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_2, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_2.dyn_VC++_32_none_high.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test3_2, mutator: test3_2, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_2, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_2.dyn_VC++_32_none_max.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test3_2, mutator: test3_2, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_2, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_2.dyn_VC++_32_none_none.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test3_2, mutator: test3_2, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_2, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_3.dyn_VC_32_none_low.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test3_3, mutator: test3_3, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_3, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_3.dyn_VC_32_none_high.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test3_3, mutator: test3_3, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_3, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_3.dyn_VC_32_none_max.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test3_3, mutator: test3_3, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_3, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_3.dyn_VC_32_none_none.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test3_3, mutator: test3_3, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_3, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_3.dyn_VC++_32_none_low.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test3_3, mutator: test3_3, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_3, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_3.dyn_VC++_32_none_high.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test3_3, mutator: test3_3, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_3, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_3.dyn_VC++_32_none_max.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test3_3, mutator: test3_3, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_3, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_3.dyn_VC++_32_none_none.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test3_3, mutator: test3_3, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_3, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_4.dyn_VC_32_none_low.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test3_4, mutator: test3_4, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_4, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_4.dyn_VC_32_none_high.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test3_4, mutator: test3_4, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_4, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_4.dyn_VC_32_none_max.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test3_4, mutator: test3_4, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_4, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_4.dyn_VC_32_none_none.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test3_4, mutator: test3_4, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_4, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_4.dyn_VC++_32_none_low.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test3_4, mutator: test3_4, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_4, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_4.dyn_VC++_32_none_high.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test3_4, mutator: test3_4, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_4, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_4.dyn_VC++_32_none_max.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test3_4, mutator: test3_4, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_4, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_4.dyn_VC++_32_none_none.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test3_4, mutator: test3_4, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_4, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_7.dyn_VC_32_none_low.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test3_7, mutator: test3_7, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_7, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_7.dyn_VC_32_none_high.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test3_7, mutator: test3_7, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_7, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_7.dyn_VC_32_none_max.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test3_7, mutator: test3_7, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_7, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_7.dyn_VC_32_none_none.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test3_7, mutator: test3_7, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_7, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_7.dyn_VC++_32_none_low.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test3_7, mutator: test3_7, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_7, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_7.dyn_VC++_32_none_high.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test3_7, mutator: test3_7, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_7, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_7.dyn_VC++_32_none_max.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test3_7, mutator: test3_7, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_7, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test3_7.dyn_VC++_32_none_none.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test3_7, mutator: test3_7, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test3_7, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test4_1.dyn_VC_32_none_low.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test4_1, mutator: test4_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test4_1, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test4_1.dyn_VC_32_none_high.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test4_1, mutator: test4_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test4_1, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test4_1.dyn_VC_32_none_max.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test4_1, mutator: test4_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test4_1, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test4_1.dyn_VC_32_none_none.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test4_1, mutator: test4_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test4_1, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test4_1.dyn_VC++_32_none_low.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test4_1, mutator: test4_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test4_1, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test4_1.dyn_VC++_32_none_high.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test4_1, mutator: test4_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test4_1, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test4_1.dyn_VC++_32_none_max.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test4_1, mutator: test4_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test4_1, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test4_1.dyn_VC++_32_none_none.exe", 
		SELFSTART, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test4_1, mutator: test4_1, grouped: false, pic: none, start_state: selfstart, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test4_1, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_1.dyn_VC_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test_stack_1, mutator: test_stack_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_1, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_1.dyn_VC_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test_stack_1, mutator: test_stack_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_1, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_1.dyn_VC_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test_stack_1, mutator: test_stack_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_1, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_1.dyn_VC_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test_stack_1, mutator: test_stack_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_1, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_1.dyn_VC++_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test_stack_1, mutator: test_stack_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_1, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_1.dyn_VC++_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test_stack_1, mutator: test_stack_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_1, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_1.dyn_VC++_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test_stack_1, mutator: test_stack_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_1, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_1.dyn_VC++_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test_stack_1, mutator: test_stack_1, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_1, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_3.dyn_VC_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "low", "32", "NONE");
  add_test(rg, "{test: test_stack_3, mutator: test_stack_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_3, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_3.dyn_VC_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "high", "32", "NONE");
  add_test(rg, "{test: test_stack_3, mutator: test_stack_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_3, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_3.dyn_VC_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "max", "32", "NONE");
  add_test(rg, "{test: test_stack_3, mutator: test_stack_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_3, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_3.dyn_VC_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC", "none", "32", "NONE");
  add_test(rg, "{test: test_stack_3, mutator: test_stack_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_3, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_3.dyn_VC++_32_none_low.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "low", "32", "NONE");
  add_test(rg, "{test: test_stack_3, mutator: test_stack_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_3, mutatorstart: local, optimization: low, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_3.dyn_VC++_32_none_high.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "high", "32", "NONE");
  add_test(rg, "{test: test_stack_3, mutator: test_stack_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_3, mutatorstart: local, optimization: high, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_3.dyn_VC++_32_none_max.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "max", "32", "NONE");
  add_test(rg, "{test: test_stack_3, mutator: test_stack_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_3, mutatorstart: local, optimization: max, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
  rg = new RunGroup("test_stack_3.dyn_VC++_32_none_none.exe", 
		STOPPED, CREATE, TNone, PNone, 
		local, local, no_launch, 
		DynamicLink, true, nonPIC, 
		"dyninst", "VC++", "none", "32", "NONE");
  add_test(rg, "{test: test_stack_3, mutator: test_stack_3, grouped: false, pic: none, start_state: stopped, format: dynamicMutatee, process_mode: None, abi: 32, thread_mode: None, mutateeruntime: no_launch, platmode: NONE, mutatee: test_stack_3, mutatorstart: local, optimization: none, mutateestart: local, compiler: VC++, run_mode: createProcess}");
  fini_group(rg);
}
